#!/bin/bash
# =============================================================================
# CIS RHEL 9 - PRE-HARDENING COMPANION SCRIPT
# Optimised for: Microsoft Tunnel VPN + Podman on Azure RHEL 9
#
# Run this BEFORE the official CIS Build Kit
#
# What this does:
#  1. Drops safe exclusion list into CIS kit folder
#  2. System updates via dnf
#  3. Installs required packages (aide, auditd, chrony, rsyslog, etc.)
#  4. Configures SSH (port 22, password auth, CIS compliant)
#  5. Configures firewalld (allows SSH + Tunnel ports, loopback)
#  6. Enables IP forwarding (REQUIRED for Microsoft Tunnel VPN)
#  7. Loads ip_tables module (required by RHEL9 + Podman/Tunnel)
#  8. Installs and configures Podman
#  9. Kernel hardening via sysctl (Tunnel-safe)
# 10. Configures auditd with full CIS rule set
# 11. Configures rsyslog and journald
# 12. Enables SELinux enforcing
# 13. Configures AIDE file integrity
# 14. Sudo hardening (safe)
# 15. Cron hardening
# 16. Legal banners
# 17. File permissions
# 18. Auto updates
#
# Usage:
#   sudo bash rhel9-cis-pre-harden.sh /path/to/cis_lbk_red_hat_enterprise_linux_9
#
# Then run CIS kit:
#   sudo bash red_hat_enterprise_linux_9.sh
#   Select: L1S
# =============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

LOG_FILE="/var/log/rhel9-cis-pre-harden-$(date +%Y%m%d-%H%M%S).log"

log()    { echo -e "${GREEN}[+]${NC} $1" | tee -a "$LOG_FILE"; }
warn()   { echo -e "${YELLOW}[!]${NC} $1" | tee -a "$LOG_FILE"; }
err()    { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"; }
header() { echo -e "\n${CYAN}=== $1 ===${NC}" | tee -a "$LOG_FILE"; }

if [[ $EUID -ne 0 ]]; then
  err "Run as root: sudo bash $0"
  exit 1
fi

# Find CIS kit directory
CIS_KIT_DIR="${1:-}"
if [[ -z "$CIS_KIT_DIR" ]]; then
  CIS_KIT_DIR=$(find /root /home /opt /tmp -maxdepth 5 -name "red_hat_enterprise_linux_9.sh" 2>/dev/null | head -1 | xargs dirname 2>/dev/null || true)
fi

echo -e "${CYAN}"
echo "  ╔══════════════════════════════════════════════════════════╗"
echo "  ║   CIS RHEL 9 Pre-Hardening — Microsoft Tunnel Edition   ║"
echo "  ║   Podman + Azure Tunnel Safe | SSH Port 22              ║"
echo "  ╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo "Log: $LOG_FILE"
[[ -n "$CIS_KIT_DIR" ]] && log "CIS kit found at: $CIS_KIT_DIR" || warn "CIS kit not found — exclusion list must be copied manually"
echo ""
warn "This will harden RHEL 9 for CIS L1S compliance."
warn "IP forwarding will remain ENABLED (required for Microsoft Tunnel VPN)."
read -rp "Continue? (yes/no): " CONFIRM
[[ "$CONFIRM" != "yes" ]] && { echo "Aborted."; exit 0; }

# =============================================================================
header "1. Deploy Safe Exclusion List"
# =============================================================================
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
EXCL_SRC="$SCRIPT_DIR/rhel9_exclusion_list.txt"

if [[ -n "$CIS_KIT_DIR" && -f "$EXCL_SRC" ]]; then
  cp "$EXCL_SRC" "$CIS_KIT_DIR/exclusion_list.txt"
  log "exclusion_list.txt deployed to $CIS_KIT_DIR"
elif [[ -n "$CIS_KIT_DIR" ]]; then
  warn "rhel9_exclusion_list.txt not found next to this script."
  warn "Copy rhel9_exclusion_list.txt manually to: $CIS_KIT_DIR/exclusion_list.txt"
else
  warn "CIS kit path not found. Copy rhel9_exclusion_list.txt manually."
fi

# =============================================================================
header "2. System Updates"
# =============================================================================
log "Updating system via dnf..."
dnf update -y -q
log "System updated."

# =============================================================================
header "3. Install Required Packages"
# =============================================================================
log "Installing required packages..."
dnf install -y \
  aide \
  audit \
  chrony \
  rsyslog \
  sudo \
  firewalld \
  podman \
  container-tools \
  policycoreutils \
  policycoreutils-python-utils \
  selinux-policy-targeted \
  libselinux-utils \
  setroubleshoot-server \
  mcstrans \
  cronie \
  logrotate \
  crypto-policies \
  crypto-policies-scripts \
  dnf-automatic \
  acl \
  net-tools \
  lsof \
  2>/dev/null | tail -5

log "All packages installed."

# Remove setroubleshoot and mcstrans as CIS requires (1.6.1.7 / 1.6.1.8)
dnf remove -y setroubleshoot mcstrans 2>/dev/null || true
log "setroubleshoot and mcstrans removed per CIS 1.6.1.7/1.6.1.8"

# =============================================================================
header "4. SSH Hardening (Port 22, Password Auth, CIS 5.2.x)"
# =============================================================================
log "Backing up sshd_config..."
cp /etc/ssh/sshd_config "/etc/ssh/sshd_config.bak.$(date +%Y%m%d)" 2>/dev/null || true

log "Writing CIS-compliant sshd_config..."
cat > /etc/ssh/sshd_config <<'EOF'
# CIS RHEL 9 Hardened SSH Configuration
Protocol 2
Port 22

# Authentication - password based, no keys required
PermitRootLogin no
PasswordAuthentication yes
PubkeyAuthentication no
PermitEmptyPasswords no
UsePAM yes

# CIS 5.2.6 - PAM enabled
# CIS 5.2.7 - Root login disabled
# CIS 5.2.8 - HostbasedAuthentication
HostbasedAuthentication no

# CIS 5.2.9 - Empty passwords
# CIS 5.2.10 - User environment
PermitUserEnvironment no

# CIS 5.2.11 - IgnoreRhosts
IgnoreRhosts yes

# CIS 5.2.12 - X11 forwarding
X11Forwarding no

# NOTE: AllowTcpForwarding kept enabled (excluded 5.2.13)
# Microsoft Tunnel requires TCP forwarding
AllowTcpForwarding yes

# CIS 5.2.14 - Use system crypto policy
# (do not override with manual ciphers on RHEL9)

# CIS 5.2.15 - Warning banner
Banner /etc/issue.net

# CIS 5.2.16 - MaxAuthTries
MaxAuthTries 4

# CIS 5.2.17 - MaxStartups
MaxStartups 10:30:60

# CIS 5.2.18 - MaxSessions
MaxSessions 10

# CIS 5.2.19 - LoginGraceTime
LoginGraceTime 60

# CIS 5.2.20 - Idle timeout
ClientAliveInterval 15
ClientAliveCountMax 3

# CIS 5.2.5 - LogLevel
LogLevel VERBOSE

# Disable GSSAPI
GSSAPIAuthentication no

# Disable agent forwarding
AllowAgentForwarding no
PermitTunnel no
EOF

chmod 600 /etc/ssh/sshd_config
chown root:root /etc/ssh/sshd_config

log "Validating SSH config..."
if sshd -t; then
  systemctl daemon-reload
  systemctl restart sshd
  sleep 2
  systemctl is-active sshd && log "SSH running on port 22." || err "SSH failed to start!"
else
  err "SSH config invalid — restoring backup."
  cp "/etc/ssh/sshd_config.bak.$(date +%Y%m%d)" /etc/ssh/sshd_config
  systemctl restart sshd
fi

# SSH key file permissions (CIS 5.2.2 / 5.2.3)
find /etc/ssh -name "ssh_host_*_key" -exec chmod 600 {} \; -exec chown root:root {} \;
find /etc/ssh -name "ssh_host_*_key.pub" -exec chmod 644 {} \; -exec chown root:root {} \;
log "SSH host key permissions set."

# =============================================================================
header "5. Firewalld Configuration (CIS 3.4.x)"
# =============================================================================
log "Configuring firewalld..."
systemctl enable firewalld
systemctl start firewalld

# Set default zone
firewall-cmd --set-default-zone=drop 2>/dev/null || firewall-cmd --set-default-zone=public

# Allow SSH
firewall-cmd --permanent --add-service=ssh

# Microsoft Tunnel required ports
# Port 443 - Tunnel HTTPS/TLS
# Port 8080 - Tunnel readiness probe (internal)
firewall-cmd --permanent --add-port=443/tcp
firewall-cmd --permanent --add-port=443/udp

# Allow established/related traffic (loopback handled by firewalld internally)
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="127.0.0.1" accept'
firewall-cmd --permanent --add-rich-rule='rule family="ipv6" source address="::1" accept'

# Podman bridge networks (Microsoft Tunnel uses these)
# Podman default: 10.88.0.0/16
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="10.88.0.0/16" accept'

firewall-cmd --reload
log "Firewalld configured — SSH(22), HTTPS(443), Podman bridge allowed."
firewall-cmd --list-all | tee -a "$LOG_FILE"

# Restart SSH after firewall changes
sleep 2
systemctl restart sshd
log "SSH restarted post-firewall."

# =============================================================================
header "6. IP Forwarding (REQUIRED for Microsoft Tunnel VPN)"
# =============================================================================
log "Enabling IP forwarding for Microsoft Tunnel VPN routing..."
cat > /etc/sysctl.d/99-tunnel-forwarding.conf <<'EOF'
# REQUIRED for Microsoft Tunnel VPN packet routing
# CIS 3.2.1 is excluded in exclusion_list.txt
net.ipv4.ip_forward = 1
net.ipv6.conf.all.forwarding = 0
EOF

sysctl -p /etc/sysctl.d/99-tunnel-forwarding.conf >> "$LOG_FILE" 2>&1
log "IP forwarding enabled (IPv4 only, IPv6 forwarding disabled)."

# =============================================================================
header "7. Load ip_tables Module (Required by RHEL9 + Tunnel)"
# =============================================================================
log "Loading ip_tables kernel module..."
modprobe ip_tables 2>/dev/null && log "ip_tables loaded." || warn "ip_tables already loaded or not needed."
modprobe ip6_tables 2>/dev/null || true

# Make persistent across reboots
cat > /etc/modules-load.d/tunnel-iptables.conf <<'EOF'
# Required by Microsoft Tunnel on RHEL 9
# RHEL 9 does not auto-load ip_tables
ip_tables
ip6_tables
EOF
log "ip_tables configured to load on boot."

# =============================================================================
header "8. Podman Configuration"
# =============================================================================
log "Configuring Podman for Microsoft Tunnel..."

# Enable Podman socket (required by some Tunnel versions)
systemctl enable podman.socket 2>/dev/null || true
systemctl start podman.socket 2>/dev/null || true

# Set SELinux to allow Podman containers
setsebool -P container_manage_cgroup 1 2>/dev/null || true

# Podman registries config
if [[ ! -f /etc/containers/registries.conf ]]; then
  cat > /etc/containers/registries.conf <<'EOF'
[registries.search]
registries = ['registry.access.redhat.com', 'registry.redhat.io', 'docker.io']
EOF
fi

log "Podman configured."
podman --version | tee -a "$LOG_FILE"

# =============================================================================
header "9. Kernel Hardening - sysctl (CIS 3.x - Tunnel Safe)"
# =============================================================================
log "Applying sysctl hardening (IP forwarding preserved for Tunnel)..."
cat > /etc/sysctl.d/99-cis-rhel9.conf <<'EOF'
# CIS RHEL 9 Kernel Hardening
# NOTE: ip_forward is managed separately in 99-tunnel-forwarding.conf

# CIS 3.2.2 - Packet redirect sending disabled
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# CIS 3.3.1 - Source routed packets not accepted
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0

# CIS 3.3.2 - ICMP redirects not accepted
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0

# CIS 3.3.3 - Secure ICMP redirects not accepted
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0

# CIS 3.3.4 - Suspicious packets logged
net.ipv4.conf.all.log_martians = 1
net.ipv4.conf.default.log_martians = 1

# CIS 3.3.5 - Broadcast ICMP ignored
net.ipv4.icmp_echo_ignore_broadcasts = 1

# CIS 3.3.6 - Bogus ICMP ignored
net.ipv4.icmp_ignore_bogus_error_responses = 1

# CIS 3.3.7 - Reverse path filtering
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1

# CIS 3.3.8 - TCP SYN cookies
net.ipv4.tcp_syncookies = 1

# CIS 3.3.9 - IPv6 router advertisements not accepted
net.ipv6.conf.all.accept_ra = 0
net.ipv6.conf.default.accept_ra = 0

# CIS 1.5.3 - ASLR
kernel.randomize_va_space = 2

# Additional kernel hardening
kernel.dmesg_restrict = 1
kernel.kptr_restrict = 2
kernel.yama.ptrace_scope = 1
kernel.sysrq = 0
fs.suid_dumpable = 0
fs.protected_hardlinks = 1
fs.protected_symlinks = 1
EOF

sysctl -p /etc/sysctl.d/99-cis-rhel9.conf >> "$LOG_FILE" 2>&1
log "sysctl CIS hardening applied (IP forwarding preserved)."

# =============================================================================
header "10. SELinux (CIS 1.6.x)"
# =============================================================================
log "Ensuring SELinux is enforcing..."
setenforce 1 2>/dev/null || true

# Set enforcing in config file
sed -i 's/^SELINUX=.*/SELINUX=enforcing/' /etc/selinux/config
sed -i 's/^SELINUXTYPE=.*/SELINUXTYPE=targeted/' /etc/selinux/config

# Verify
sestatus | tee -a "$LOG_FILE"
log "SELinux enforcing with targeted policy."

# =============================================================================
header "11. Audit Daemon - auditd (CIS 4.1.x)"
# =============================================================================
log "Configuring auditd..."

# CIS 4.1.2.1 - Storage size
sed -i 's/^max_log_file =.*/max_log_file = 100/' /etc/audit/auditd.conf
# CIS 4.1.2.2 - Don't auto-delete
sed -i 's/^max_log_file_action =.*/max_log_file_action = keep_logs/' /etc/audit/auditd.conf
# CIS 4.1.2.3 excluded (danger - shutdown on full) - set to syslog instead
sed -i 's/^disk_full_action =.*/disk_full_action = syslog/' /etc/audit/auditd.conf
sed -i 's/^admin_space_left_action =.*/admin_space_left_action = email/' /etc/audit/auditd.conf

# CIS 4.1.1.2 - Audit processes before auditd starts
if ! grep -q "audit=1" /proc/cmdline; then
  grubby --update-kernel=ALL --args="audit=1 audit_backlog_limit=8192" >> "$LOG_FILE" 2>&1
  log "Added audit=1 to kernel cmdline"
fi

# Write full CIS-aligned audit rules for RHEL9
cat > /etc/audit/rules.d/99-cis-rhel9.rules <<'EOF'
## CIS RHEL 9 Benchmark - Audit Rules
-D
-b 8192
-f 1
--backlog_wait_time 60000

# CIS 4.1.3.4 - Date/time changes
-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change
-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
-a always,exit -F arch=b64 -S clock_settime -k time-change
-a always,exit -F arch=b32 -S clock_settime -k time-change
-w /etc/localtime -p wa -k time-change

# CIS 4.1.3.8 - User/group info changes
-w /etc/group   -p wa -k identity
-w /etc/passwd  -p wa -k identity
-w /etc/gshadow -p wa -k identity
-w /etc/shadow  -p wa -k identity
-w /etc/security/opasswd -p wa -k identity

# CIS 4.1.3.5 - Network environment changes
-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale
-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale
-w /etc/issue     -p wa -k system-locale
-w /etc/issue.net -p wa -k system-locale
-w /etc/hosts     -p wa -k system-locale
-w /etc/sysconfig/network -p wa -k system-locale

# CIS 4.1.3.14 - MAC policy (SELinux)
-w /etc/selinux/      -p wa -k MAC-policy
-w /usr/share/selinux/ -p wa -k MAC-policy

# CIS 4.1.3.9 - DAC permission modifications
-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod

# CIS 4.1.3.7 - Unsuccessful file access
-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM  -F auid>=1000 -F auid!=4294967295 -k access
-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM  -F auid>=1000 -F auid!=4294967295 -k access

# CIS 4.1.3.6 - Privileged commands
-a always,exit -F path=/usr/bin/chsh    -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/bin/newgrp  -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/bin/sudo    -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/bin/su      -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/useradd  -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/userdel  -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/usermod  -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/groupadd -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/groupdel -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/sbin/groupmod -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd
-a always,exit -F path=/usr/bin/passwd     -F perm=x -F auid>=1000 -F auid!=4294967295 -k priv_cmd

# CIS 4.1.3.10 - Successful filesystem mounts
-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts

# CIS 4.1.3.13 - File deletion
-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete

# CIS 4.1.3.1 - Sudoers changes
-w /etc/sudoers   -p wa -k scope
-w /etc/sudoers.d -p wa -k scope

# CIS 4.1.3.2 - Actions as another user
-a always,exit -F arch=b64 -C euid!=uid -F euid=0 -S execve -k actions
-a always,exit -F arch=b32 -C euid!=uid -F euid=0 -S execve -k actions

# CIS 4.1.3.3 - Sudo log file changes
-w /var/log/sudo.log -p wa -k sudo_log_file

# CIS 4.1.3.11 / 4.1.3.12 - Session/login-logout
-w /var/run/utmp -p wa -k session
-w /var/log/wtmp -p wa -k session
-w /var/log/btmp -p wa -k session
-w /var/log/lastlog -p wa -k logins

# CIS 4.1.3.19 - Kernel module loading
-w /sbin/insmod    -p x -k modules
-w /sbin/rmmod     -p x -k modules
-w /sbin/modprobe  -p x -k modules
-a always,exit -F arch=b64 -S init_module -S delete_module -k modules

# CIS 4.1.3.15/16/17/18 - chcon, setfacl, chacl, usermod
-a always,exit -F path=/usr/bin/chcon   -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng
-a always,exit -F path=/usr/bin/setfacl -F perm=x -F auid>=1000 -F auid!=4294967295 -k perm_chng
-a always,exit -F path=/usr/sbin/usermod -F perm=x -F auid>=1000 -F auid!=4294967295 -k usermod

# SSH config changes
-w /etc/ssh/sshd_config -p wa -k sshd_config

# CIS 4.1.3.20 - Immutable (must be last)
-e 2
EOF

chmod 640 /etc/audit/rules.d/99-cis-rhel9.rules
chown root:root /etc/audit/rules.d/99-cis-rhel9.rules

systemctl enable auditd
systemctl restart auditd
log "auditd configured with full CIS rule set."

# =============================================================================
header "12. Rsyslog (CIS 4.2.1.x)"
# =============================================================================
log "Configuring rsyslog..."
systemctl enable rsyslog
systemctl start rsyslog

# CIS 4.2.1.4 - Log file creation mode
if grep -q "FileCreateMode" /etc/rsyslog.conf; then
  sed -i 's/^\$FileCreateMode.*/\$FileCreateMode 0640/' /etc/rsyslog.conf
else
  echo "\$FileCreateMode 0640" >> /etc/rsyslog.conf
fi

# CIS 4.2.1.7 - Not receiving remote logs
sed -i 's/^#\?\s*module(load="imudp")/# module(load="imudp")/' /etc/rsyslog.conf
sed -i 's/^#\?\s*input(type="imudp"/# input(type="imudp"/' /etc/rsyslog.conf
sed -i 's/^#\?\s*module(load="imtcp")/# module(load="imtcp")/' /etc/rsyslog.conf
sed -i 's/^#\?\s*input(type="imtcp"/# input(type="imtcp"/' /etc/rsyslog.conf

systemctl restart rsyslog
log "rsyslog configured."

# =============================================================================
header "13. Journald (CIS 4.2.2.x)"
# =============================================================================
log "Configuring journald..."
mkdir -p /etc/systemd/journald.conf.d/
cat > /etc/systemd/journald.conf.d/cis.conf <<'EOF'
[Journal]
# CIS 4.2.2.3 - Compress large files
Compress=yes
# CIS 4.2.2.4 - Write to disk
Storage=persistent
# CIS 4.2.2.5 - Don't forward to rsyslog
ForwardToSyslog=no
EOF

systemctl restart systemd-journald
log "journald configured."

# =============================================================================
header "14. Chrony Time Sync (CIS 2.1.x)"
# =============================================================================
log "Configuring chrony..."
systemctl enable chronyd
systemctl start chronyd
systemctl restart chronyd
log "Chrony time sync active."

# =============================================================================
header "15. AIDE File Integrity (CIS 1.3.x)"
# =============================================================================
log "Initialising AIDE (may take a few minutes)..."
mkdir -p /var/log/aide

# Initialise AIDE database
aide --init >> "$LOG_FILE" 2>&1 || true
mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz 2>/dev/null || true

# CIS 1.3.2 - Regular integrity checks
cat > /etc/cron.d/aide-cis <<'EOF'
# CIS 1.3.2 - Daily filesystem integrity check
0 5 * * * root /usr/sbin/aide --check >> /var/log/aide/aide-check.log 2>&1
EOF

log "AIDE initialised, daily check at 05:00."

# =============================================================================
header "16. Sudo Hardening (CIS 5.3.x)"
# =============================================================================
log "Configuring sudo..."
cat > /etc/sudoers.d/99-cis-rhel9 <<'EOF'
# CIS 5.3.2 - Use pty for sudo
Defaults use_pty
# CIS 5.3.3 - Sudo log file
Defaults logfile="/var/log/sudo.log"
# CIS 5.3.6 - Re-auth timeout (5 min)
Defaults timestamp_timeout=5
EOF
chmod 440 /etc/sudoers.d/99-cis-rhel9
log "Sudo CIS settings applied."

# =============================================================================
header "17. Cron Hardening (CIS 5.1.x)"
# =============================================================================
log "Hardening cron..."
chmod 600 /etc/crontab && chown root:root /etc/crontab
for dir in /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d; do
  [[ -d "$dir" ]] && chmod 700 "$dir" && chown root:root "$dir"
done

# CIS 5.1.8 / 5.1.9 - Restrict cron/at to root only
echo "root" > /etc/cron.allow && chmod 600 /etc/cron.allow
rm -f /etc/cron.deny
echo "root" > /etc/at.allow && chmod 600 /etc/at.allow
rm -f /etc/at.deny

# CIS 5.1.1 - Ensure crond is enabled
systemctl enable crond
systemctl start crond
log "Cron hardened."

# =============================================================================
header "18. Legal Banners (CIS 1.7.x)"
# =============================================================================
cat > /etc/issue <<'EOF'
Authorized use only. All activity is monitored and logged.
EOF
cat > /etc/issue.net <<'EOF'
*******************************************************************************
WARNING: Unauthorized access to this system is strictly prohibited.
All connections, commands, and activities are monitored and logged.
Disconnect IMMEDIATELY if you are not an authorized user.
*******************************************************************************
EOF
cat > /etc/motd <<'EOF'
================================================================================
  NOTICE: Authorized use only. All activity is monitored and logged.
================================================================================
EOF
chmod 644 /etc/issue /etc/issue.net /etc/motd
chown root:root /etc/issue /etc/issue.net /etc/motd
log "Legal banners set."

# =============================================================================
header "19. File Permissions (CIS 6.1.x)"
# =============================================================================
log "Setting critical file permissions..."
chmod 644 /etc/passwd  && chown root:root /etc/passwd
chmod 000 /etc/shadow  && chown root:root /etc/shadow
chmod 644 /etc/group   && chown root:root /etc/group
chmod 000 /etc/gshadow && chown root:root /etc/gshadow
[[ -f /etc/passwd- ]]  && chmod 644 /etc/passwd-  && chown root:root /etc/passwd-
[[ -f /etc/shadow- ]]  && chmod 000 /etc/shadow-  && chown root:root /etc/shadow-
[[ -f /etc/group- ]]   && chmod 644 /etc/group-   && chown root:root /etc/group-
[[ -f /etc/gshadow- ]] && chmod 000 /etc/gshadow- && chown root:root /etc/gshadow-
log "File permissions set."

# =============================================================================
header "20. Crypto Policy (CIS 1.1)"
# =============================================================================
log "Setting system-wide crypto policy to DEFAULT (not LEGACY)..."
update-crypto-policies --set DEFAULT >> "$LOG_FILE" 2>&1
log "Crypto policy set to DEFAULT."

# =============================================================================
header "21. Core Dumps Restricted (CIS 1.5.x)"
# =============================================================================
# CIS 1.5.1 - Core dump storage disabled
if systemctl is-active systemd-coredump.socket &>/dev/null; then
  mkdir -p /etc/systemd/coredump.conf.d/
  cat > /etc/systemd/coredump.conf.d/cis.conf <<'EOF'
[Coredump]
Storage=none
ProcessSizeMax=0
EOF
fi

cat > /etc/sysctl.d/99-coredump.conf <<'EOF'
fs.suid_dumpable = 0
EOF
sysctl -p /etc/sysctl.d/99-coredump.conf >> "$LOG_FILE" 2>&1

# CIS 1.5.2 - Core dump backtraces disabled
if [[ -f /etc/systemd/coredump.conf ]]; then
  sed -i 's/^#\?Backtrace=.*/Backtrace=no/' /etc/systemd/coredump.conf
fi

if ! grep -q "* hard core 0" /etc/security/limits.conf; then
  echo "* hard core 0" >> /etc/security/limits.conf
  echo "* soft core 0" >> /etc/security/limits.conf
fi
log "Core dumps restricted."

# =============================================================================
header "22. DNF Automatic Updates (CIS 1.9)"
# =============================================================================
log "Configuring automatic security updates..."
sed -i 's/^upgrade_type =.*/upgrade_type = security/' /etc/dnf/automatic.conf 2>/dev/null || true
sed -i 's/^apply_updates =.*/apply_updates = yes/' /etc/dnf/automatic.conf 2>/dev/null || true
systemctl enable dnf-automatic.timer 2>/dev/null || true
log "DNF automatic security updates enabled."

# =============================================================================
header "Done - Summary"
# =============================================================================
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       RHEL9 PRE-HARDENING COMPLETE ✓                    ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYAN}SSH:${NC}            Port 22, password auth, CIS compliant"
echo -e "  ${CYAN}Firewalld:${NC}      SSH(22) + HTTPS(443) + Podman bridge open"
echo -e "  ${CYAN}IP Forwarding:${NC}  ENABLED (required for Microsoft Tunnel VPN)"
echo -e "  ${CYAN}ip_tables:${NC}      Loaded and persistent (required for Tunnel)"
echo -e "  ${CYAN}Podman:${NC}         Installed and configured"
echo -e "  ${CYAN}SELinux:${NC}        Enforcing (targeted policy)"
echo -e "  ${CYAN}auditd:${NC}         Active with full CIS rule set"
echo -e "  ${CYAN}rsyslog:${NC}        Active and configured"
echo -e "  ${CYAN}journald:${NC}       Persistent, compressed"
echo -e "  ${CYAN}Chrony:${NC}         Time sync active"
echo -e "  ${CYAN}AIDE:${NC}           Initialised, daily check at 05:00"
echo -e "  ${CYAN}sysctl:${NC}         CIS 3.x kernel settings applied"
echo -e "  ${CYAN}Crypto policy:${NC}  DEFAULT (not LEGACY)"
echo -e "  ${CYAN}Passwords:${NC}      Unchanged — no expiry or complexity changes"
echo -e "  ${CYAN}Log:${NC}            $LOG_FILE"
echo ""

if [[ -n "$CIS_KIT_DIR" ]]; then
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${YELLOW}NEXT STEP — Run the CIS Build Kit:${NC}"
  echo -e "  cd $CIS_KIT_DIR"
  echo -e "  sudo bash red_hat_enterprise_linux_9.sh"
  echo -e "  Select: 1 (L1S - Level 1 Server)"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
else
  echo -e "${YELLOW}NEXT STEP — Copy rhel9_exclusion_list.txt to your CIS kit folder${NC}"
  echo -e "  then: sudo bash red_hat_enterprise_linux_9.sh"
  echo -e "  Select: 1 (L1S)"
fi

echo ""
warn "Test SSH in a NEW terminal before rebooting."
warn "Reboot when ready to apply all kernel/sysctl changes."
